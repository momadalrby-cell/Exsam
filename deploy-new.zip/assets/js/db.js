// db.js — open SQLite via sql.js, seed on first run, persist on every change
const DB = (() => {
  let db = null;
  const SCHEMA = `
    CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, username TEXT NOT NULL UNIQUE,
      password_hash TEXT NOT NULL, display_name TEXT NOT NULL, role TEXT NOT NULL CHECK(role IN ('admin','user')),
      created_at TEXT NOT NULL DEFAULT (datetime('now')));
    CREATE TABLE IF NOT EXISTS quizzes(id INTEGER PRIMARY KEY, pkg_id TEXT NOT NULL UNIQUE,
      title TEXT NOT NULL, sections_text TEXT NOT NULL DEFAULT '', description TEXT NOT NULL DEFAULT '',
      status TEXT NOT NULL DEFAULT 'draft' CHECK(status IN ('draft','published')),
      sort_order INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL DEFAULT (datetime('now')),
      updated_at TEXT NOT NULL DEFAULT (datetime('now')));
    CREATE TABLE IF NOT EXISTS questions(id INTEGER PRIMARY KEY, quiz_id INTEGER NOT NULL REFERENCES quizzes(id) ON DELETE CASCADE,
      ord INTEGER NOT NULL, text TEXT NOT NULL, options TEXT NOT NULL, answer INTEGER, image TEXT, table_html TEXT,
      section INTEGER NOT NULL, section_name TEXT NOT NULL, letters_only INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL DEFAULT (datetime('now')));
    CREATE TABLE IF NOT EXISTS attempts(id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      quiz_id INTEGER REFERENCES quizzes(id) ON DELETE SET NULL,
      answers TEXT NOT NULL, correct INTEGER NOT NULL DEFAULT 0, wrong INTEGER NOT NULL DEFAULT 0,
      unanswered INTEGER NOT NULL DEFAULT 0, total_scored INTEGER NOT NULL DEFAULT 0,
      pct INTEGER NOT NULL DEFAULT 0, submitted_at TEXT NOT NULL DEFAULT (datetime('now')));
    CREATE TABLE IF NOT EXISTS attempt_progress(user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      quiz_id INTEGER NOT NULL REFERENCES quizzes(id) ON DELETE CASCADE, answers TEXT NOT NULL DEFAULT '{}',
      updated_at TEXT NOT NULL DEFAULT (datetime('now')), PRIMARY KEY(user_id, quiz_id));
    CREATE TABLE IF NOT EXISTS mohammed_mistakes(id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      question_id INTEGER REFERENCES questions(id) ON DELETE SET NULL, quiz_id INTEGER,
      q_text TEXT NOT NULL, q_options TEXT NOT NULL, q_answer INTEGER, q_section TEXT NOT NULL DEFAULT '', quiz_title TEXT NOT NULL DEFAULT '',
      wrong_count INTEGER NOT NULL DEFAULT 1, correct_count INTEGER NOT NULL DEFAULT 0,
      status TEXT NOT NULL DEFAULT 'needs_review' CHECK(status IN ('needs_review','mastered')),
      first_wrong_at TEXT NOT NULL DEFAULT (datetime('now')), last_wrong_at TEXT NOT NULL DEFAULT (datetime('now')), mastered_at TEXT,
      UNIQUE(user_id, question_id));
    CREATE TABLE IF NOT EXISTS jawad_mistakes(id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      question_id INTEGER REFERENCES questions(id) ON DELETE SET NULL, quiz_id INTEGER,
      q_text TEXT NOT NULL, q_options TEXT NOT NULL, q_answer INTEGER, q_section TEXT NOT NULL DEFAULT '', quiz_title TEXT NOT NULL DEFAULT '',
      wrong_count INTEGER NOT NULL DEFAULT 1, correct_count INTEGER NOT NULL DEFAULT 0,
      status TEXT NOT NULL DEFAULT 'needs_review' CHECK(status IN ('needs_review','mastered')),
      first_wrong_at TEXT NOT NULL DEFAULT (datetime('now')), last_wrong_at TEXT NOT NULL DEFAULT (datetime('now')), mastered_at TEXT,
      UNIQUE(user_id, question_id));
    CREATE TABLE IF NOT EXISTS mistake_log(id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      question_id INTEGER, quiz_id INTEGER, attempt_id INTEGER, wrong_at TEXT NOT NULL DEFAULT (datetime('now')));
    CREATE TABLE IF NOT EXISTS meta(key TEXT PRIMARY KEY, value TEXT NOT NULL);`;

  const MISTAKE_TABLES = { mohammed: 'mohammed_mistakes', jawad: 'jawad_mistakes' };
  const mistakeTableFor = username => ((String(username).trim().toLowerCase() === 'jawad') ? 'jawad_mistakes' : 'mohammed_mistakes');

  async function hashPassword(pw, saltHex) {
    let salt = saltHex ? Uint8Array.from(saltHex.match(/.{2}/g).map(h => parseInt(h, 16))) : crypto.getRandomValues(new Uint8Array(16));
    const key = await crypto.subtle.importKey('raw', new TextEncoder().encode(pw), 'PBKDF2', false, ['deriveBits']);
    const bits = await crypto.subtle.deriveBits({ name: 'PBKDF2', hash: 'SHA-256', salt, iterations: 100000 }, key, 256);
    const hex = b => [...new Uint8Array(b)].map(x => x.toString(16).padStart(2, '0')).join('');
    return hex(salt) + ':' + hex(bits);
  }
  async function verifyPassword(pw, stored) {
    const [saltHex, hex] = String(stored).split(':');
    if (!saltHex || !hex) return false;
    const test = await hashPassword(pw, saltHex);
    return test === stored;
  }

  async function open() {
    if (db) return db;
    const SQL = await initSqlJs({ locateFile: f => 'assets/lib/' + f });
    let bytes = await ExamStorage.load();
    if (!bytes) {
      try {
        const res = await fetch('assets/seed.db');
        if (!res.ok) throw new Error('تعذر تحميل بيانات الاختبارات (' + res.status + ')');
        const buf = await res.arrayBuffer();
        if (!buf.byteLength) throw new Error('ملف بيانات الاختبارات فارغ');
        db = new SQL.Database(new Uint8Array(buf));
        db.exec(SCHEMA);
        // لا ننشئ أي حساب هنا — يُنشأ عند أول تشغيل عبر شاشة الإعداد
        return db;
      } catch (err) {
        throw new Error('تعذر فتح منصة الاختبارات: ' + err.message + ' — افتحها عبر رابط الاستضافة (HTTPS) أو عبر خادم محلي؛ التشغيل الأول يحتاج اتصالًا بالإنترنت لتحميل المنصة.');
      }
    }
    db = new SQL.Database(bytes);
    db.exec(SCHEMA);
    return db;
  }

  async function createAccount(username, displayName, role, password) {
    const hash = await hashPassword(password);
    db.run('INSERT INTO users(username,password_hash,display_name,role) VALUES (?,?,?,?)',
      [String(username).trim().toLowerCase(), hash, String(displayName).trim(), role]);
    db.run("INSERT OR REPLACE INTO meta(key,value) VALUES ('owner', ?)", [String(username).trim().toLowerCase()]);
  }

  async function persist() {
    if (!db) return;
    const bytes = db.export();
    await ExamStorage.save(bytes);
  }

  function query(sql, params) {
    const stmt = db.prepare(sql);
    stmt.bind(params || []);
    const rows = [];
    while (stmt.step()) rows.push(stmt.getAsObject());
    stmt.free();
    return rows;
  }
  function get(sql, params) { const r = query(sql, params); return r[0] || null; }
  function run(sql, params) {
    db.run(sql, params || []);
    return { lastInsertRowid: (db.exec("SELECT last_insert_rowid() AS id")[0].values[0][0]) };
  }

  return { open, persist, query, get, run, createAccount, hashPassword, verifyPassword, mistakeTableFor, MISTAKE_TABLES };
})();
