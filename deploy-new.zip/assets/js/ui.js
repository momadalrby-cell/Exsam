// ui.js — shared helpers
const UI = (() => {
  const $ = (s, r) => (r || document).querySelector(s);
  const $$ = (s, r) => [...(r || document).querySelectorAll(s)];
  const toAr = n => String(n).replace(/[0-9]/g, d => '٠١٢٣٤٥٦٧٨٩'[+d]);
  const LETTERS = ['أ', 'ب', 'ج', 'د'];
  const escapeHTML = s => String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const hasArabic = s => /[\u0621-\u064A]/.test(s);
  const optHTML = s => s === undefined || s === null ? '' : (hasArabic(s) ? s : `<span class="ltr">${escapeHTML(s)}</span>`);
  const showToast = msg => {
    let t = $('.toast'); if (!t) { t = document.createElement('div'); t.className = 'toast'; document.body.appendChild(t); }
    t.textContent = msg; t.style.opacity = '1';
    setTimeout(() => { t.style.opacity = '0'; }, 2600);
  };
  const confirmModal = (title, body) => new Promise(resolve => {
    const back = document.createElement('div');
    back.className = 'modal-back';
    back.innerHTML = `<div class="modal"><h3>${escapeHTML(title)}</h3><p style="color:var(--muted)">${body}</p>
      <div class="row" style="justify-content:flex-end;margin-top:14px">
        <button class="btn ghost small" data-x="0">إلغاء</button>
        <button class="btn small" data-x="1" style="background:var(--gold);color:#0A0A0A">تأكيد</button>
      </div></div>`;
    document.body.appendChild(back);
    back.addEventListener('click', e => {
      const v = e.target.getAttribute('data-x');
      if (v !== null) { back.remove(); resolve(v === '1'); }
    });
  });
  const session = {
    get: () => { try { return JSON.parse(sessionStorage.getItem('exam_session') || 'null'); } catch { return null; } },
    set: u => sessionStorage.setItem('exam_session', JSON.stringify(u)),
    clear: () => sessionStorage.removeItem('exam_session'),
  };
  const go = p => { location.href = p; };
  const requireLogin = () => { const u = session.get(); if (!u) { go('index.html'); return null; } return u; };
  const requireAdmin = () => { const u = requireLogin(); if (u && u.role !== 'admin') { showToast('غير مصرّح — صلاحية المدير مطلوبة'); go('index.html'); return null; } return u; };
  const logout = () => { session.clear(); go('index.html'); };
  const answerText = (q, idx) => {
    if (idx === undefined || idx === null) return '';
    if (q.letters_only) return `الخيار ${LETTERS[idx]}`;
    return `<span class="ol" style="display:inline-grid;width:22px;height:22px;font-size:11px;place-items:center;border-radius:6px;background:#171717;border:1px solid #3a3a3a;vertical-align:middle;margin-inline-end:6px">${LETTERS[idx]}</span>${optHTML(q.options[idx])}`;
  };
  return { $, $$, toAr, LETTERS, escapeHTML, optHTML, showToast, confirmModal, session, go, requireLogin, requireAdmin, logout, answerText };
})();
