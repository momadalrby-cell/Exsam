// storage.js — abstract persistence: Capacitor Filesystem | Tauri FS | browser IndexedDB
window.ExamStorage = (() => {
  const FILE = 'exam.db';
  const isCapacitor = () => !!(window.Capacitor && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform());
  const isTauri = () => !!(window.__TAURI_INTERNALS__ || window.__TAURI__);
  const kind = isCapacitor() ? 'capacitor' : isTauri() ? 'tauri' : 'browser';

  const b64ToBytes = b64 => {
    const bin = atob(b64); const out = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
    return out;
  };
  const bytesToB64 = bytes => {
    let bin = ''; const CHUNK = 0x8000;
    for (let i = 0; i < bytes.length; i += CHUNK) bin += String.fromCharCode.apply(null, bytes.subarray(i, i + CHUNK));
    return btoa(bin);
  };

  async function loadCapacitor() {
    const FS = window.Capacitor.Plugins.Filesystem;
    try {
      const res = await FS.readFile({ path: FILE, directory: 'DATA' });
      return b64ToBytes(res.data);
    } catch { return null; }
  }
  async function saveCapacitor(bytes) {
    const FS = window.Capacitor.Plugins.Filesystem;
    await FS.writeFile({ path: FILE, directory: 'DATA', data: bytesToB64(bytes), recursive: true });
  }

  async function loadTauri() {
    const fs = window.__TAURI__ && window.__TAURI__.fs;
    try {
      const path = await fs.appDataDir();
      const res = await fs.readFile(path + '/' + FILE);
      return new Uint8Array(res);
    } catch { return null; }
  }
  async function saveTauri(bytes) {
    const fs = window.__TAURI__ && window.__TAURI__.fs;
    const dir = await fs.appDataDir();
    await fs.createDir(dir, { recursive: true }).catch(() => {});
    await fs.writeFile(dir + '/' + FILE, bytes);
  }

  function idb() {
    return new Promise((resolve, reject) => {
      const req = indexedDB.open('exam-db', 1);
      req.onupgradeneeded = () => req.result.createObjectStore('db');
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
  }
  async function loadBrowser() {
    try {
      const db = await idb();
      return await new Promise((resolve, reject) => {
        const tx = db.transaction('db', 'readonly');
        const req = tx.objectStore('db').get(FILE);
        req.onsuccess = () => resolve(req.result || null);
        req.onerror = () => reject(req.error);
      });
    } catch { return null; }
  }
  async function saveBrowser(bytes) {
    const db = await idb();
    return new Promise((resolve, reject) => {
      const tx = db.transaction('db', 'readwrite');
      tx.objectStore('db').put(bytes, FILE);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  }

  async function load() {
    if (kind === 'capacitor') return loadCapacitor();
    if (kind === 'tauri') return loadTauri();
    return loadBrowser();
  }
  async function save(bytes) {
    if (kind === 'capacitor') return saveCapacitor(bytes);
    if (kind === 'tauri') return saveTauri(bytes);
    return saveBrowser(bytes);
  }
  return { load, save, kind };
})();
