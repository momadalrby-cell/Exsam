const CACHE = 'exam-pwa-new-v1';
const PRECACHE = ["./admin_import.html","./admin_quiz.html","./assets/css/platform.css","./assets/img/s1_10.jpg","./assets/img/s1_12.jpg","./assets/img/s1_14.jpg","./assets/img/s1_17.jpg","./assets/img/s1_18.jpg","./assets/img/s1_20.jpg","./assets/img/s1_21.jpg","./assets/img/s1_22.jpg","./assets/img/s1_6.jpg","./assets/img/s1_7.jpg","./assets/img/s1_8.jpg","./assets/img/s2_10.jpg","./assets/img/s2_12.jpg","./assets/img/s2_13.jpg","./assets/img/s2_16.jpg","./assets/img/s2_17.jpg","./assets/img/s2_18.jpg","./assets/img/s2_19.jpg","./assets/img/s2_20.jpg","./assets/img/s2_21.jpg","./assets/img/s2_22.jpg","./assets/img/s2_8.jpg","./assets/img/s2_9.jpg","./assets/img/s3_11.jpg","./assets/img/s3_12.jpg","./assets/img/s3_17.jpg","./assets/img/s3_18.jpg","./assets/img/s3_20.jpg","./assets/img/s3_21.jpg","./assets/img/s3_6.jpg","./assets/img/s4_1.jpg","./assets/img/s4_10.jpg","./assets/img/s4_16.jpg","./assets/img/s4_17.jpg","./assets/img/s4_19.jpg","./assets/img/s4_20.jpg","./assets/img/s4_21.jpg","./assets/img/s4_22.jpg","./assets/img/s4_6.jpg","./assets/img/s4_8.jpg","./assets/img/s4_9.jpg","./assets/img/s5_10.jpg","./assets/img/s5_4.jpg","./assets/img/s5_7.jpg","./assets/img/s5_8.jpg","./assets/img/s5_9.jpg","./assets/img/s6_10.jpg","./assets/img/s6_8.jpg","./assets/img/s6_9.jpg","./assets/img/s7_10.jpg","./assets/img/s7_7.jpg","./assets/img/s7_8.jpg","./assets/img/s7_9.jpg","./assets/img/s8_10.jpg","./assets/img/s8_11.jpg","./assets/img/s8_7.jpg","./assets/img/s8_8.jpg","./assets/img/s8_9.jpg","./assets/img/s9_10.jpg","./assets/img/s9_2.jpg","./assets/img/s9_6.jpg","./assets/img/s9_7.jpg","./assets/img/s9_8.jpg","./assets/img/s9_9.jpg","./assets/js/db.js","./assets/js/storage.js","./assets/js/ui.js","./assets/lib/jszip.min.js","./assets/lib/pdf.min.js","./assets/lib/pdf.worker.min.js","./assets/lib/sql-wasm.js","./assets/lib/sql-wasm.wasm","./assets/seed.db","./icons/apple-touch-icon.png","./icons/favicon-32.png","./icons/icon-192.png","./icons/icon-512.png","./icons/icon-maskable-512.png","./index.html","./manifest.json","./mistakes.html","./quiz.html","./result.html"];
self.addEventListener('install', e => {
  e.waitUntil(
    caches.open(CACHE).then(c => c.addAll(PRECACHE)).then(() => self.skipWaiting())
  );
});
self.addEventListener('activate', e => {
  e.waitUntil(
    caches.keys().then(keys => Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k)))).then(() => self.clients.claim())
  );
});
self.addEventListener('fetch', e => {
  const url = new URL(e.request.url);
  if (url.origin !== location.origin) return;
  e.respondWith(
    caches.match(e.request, { ignoreSearch: true }).then(hit => hit || fetch(e.request).then(res => {
      if (res.ok) { const clone = res.clone(); caches.open(CACHE).then(c => c.put(e.request, clone)); }
      return res;
    }).catch(() => caches.match('index.html')))
  );
});
